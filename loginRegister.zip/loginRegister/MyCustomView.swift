//
//  MyCustomView.swift
//  loginRegister
//
//  Created by Abel Morales on 4/28/17.
//  Copyright © 2017 Abel Morales. All rights reserved.
//

import UIKit

class MyCustomView: UIView {

    /*
    // Only override draw() if you perform custom drawing.
    // An empty implementation adversely affects performance during animation.
    override func draw(_ rect: CGRect) {
        // Drawing code
    }
    */

}
