//
//  MenuItem.swift
//  loginRegister
//
//  Created by Abel Morales on 3/23/17.
//  Copyright © 2017 Abel Morales. All rights reserved.
//

import UIKit

public class MenuItem: NSObject {
    public var title:String
    public var price:String
    
    init(_title:String, _price:String)
    {
        title = _title
        price = _price
    }

}
